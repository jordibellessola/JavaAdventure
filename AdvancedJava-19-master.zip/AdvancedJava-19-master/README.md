# AdvancedJava-19
Repository of the assignment AdvancedJava for the STW classroom
