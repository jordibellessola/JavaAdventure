package model;

public class UsersDBFactory {
	public static UsersDB getUsersDB(){
		return new UsersDB();
	}
}
